using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Text;

namespace CheckedListViewSample
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class CheckedListViewWindow : Window
	{
		public CheckedListViewWindow()
		{
			InitializeComponent();
			SetDataContext();
		}

		private void SetDataContext()
		{
			ObservableCollection<string> items = new ObservableCollection<string>();
			items.Add("Item 1");
			items.Add("Item 2");
			items.Add("Item 3");
			items.Add("Item 4");
			items.Add("Item 5");
			DataContext = items;
		}

		private void OnShowSelectedItems(object sender, RoutedEventArgs e)
		{
			StringBuilder items = new StringBuilder();
			items.AppendFormat("Items selected count: {0}", checkedListView.SelectedItems.Count).AppendLine();
			foreach (string item in checkedListView.SelectedItems)
			{
				items.AppendLine(item);
			}
			MessageBox.Show(items.ToString());
		}

		private void OnUncheckItem(object sender, RoutedEventArgs e)
		{
			selectAll.IsChecked = false;
		}

		private void OnSelectAllChanged(object sender, RoutedEventArgs e)
		{
			if (selectAll.IsChecked.HasValue && selectAll.IsChecked.Value)
				checkedListView.SelectAll();
			else
				checkedListView.UnselectAll();
		}
	}
}