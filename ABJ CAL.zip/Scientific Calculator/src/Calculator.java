import java.awt.EventQueue;
 
import javax.swing.JFrame;
 
 
public class Calculator {
 
        public static void main(String arg[])
        {
                  CalculatorFrame calculator=new CalculatorFrame();
                                calculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                calculator.setVisible(true);
                      
        }
       
}
