import javax.swing.*;
import java.awt.event.*;


public class UnitConversion extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JComboBox c1,c2;
	JTextField tField1,tField2,tField3;
	JPanel p1,p2,p3,p4;
	JButton Convert,Clear;
	JLabel from,to;
	public UnitConversion() {
		// TODO Auto-generated constructor stub
		this.setTitle("Unit Conversion");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(450, 300);
		this.setLayout(null);
		this.c1 = new JComboBox();
		this.c2 = new JComboBox();
		
		this.c1.addItem("Select One");
		this.c1.addItem("Kilo Metre/s");
		this.c1.addItem("Metre/s");
		this.c1.addItem("Centi Metre/s");
		this.c1.addItem("Milli Metre/s");
		this.c1.addItem("Litre/s");
		this.c1.addItem("milli litre/s");
		this.c1.addItem("Kilo Gram/s");
		this.c1.addItem("Gram/s");
		this.c1.addItem("Milli Gram/s");
		this.c1.addItem("Foot/Feet");
		this.c1.addItem("Inch/es");
		this.c1.addItem("Ounce(s)");
		this.c1.addItem("Tonne(s)");
		this.c1.addItem("Yard");
		
		this.c2.addItem("Select One");
		this.c2.addItem("Kilo Metre/s");
		this.c2.addItem("Metre/s");
		this.c2.addItem("Centi Metre/s");
		this.c2.addItem("Milli Metre/s");
		this.c2.addItem("Litre/s");
		this.c2.addItem("milli litre/s");
		this.c2.addItem("Kilo Gram/s");
		this.c2.addItem("Gram/s");
		this.c2.addItem("Milli Gram/s");
		this.c2.addItem("Foot/Feet");
		this.c2.addItem("Inch/es");
		this.c2.addItem("Ounce(s)");
		this.c2.addItem("Tonne(s)");
		this.c2.addItem("Yard");

		this.tField1 = new JTextField("Enter Here!!!");
		this.tField2 = new JTextField();
		this.tField2.setEditable(false);
		this.Convert = new JButton("Convert");
		this.Clear = new JButton("Clear");
		this.from =new JLabel("From ");
		this.to = new JLabel("To");
		this.c1.setBounds(20, 20, 100, 50);
		this.from.setBounds(20, 02, 40, 20);
		this.c2.setBounds(300, 20, 100, 50);
		this.to.setBounds(300, 02, 30, 20);
		this.tField1.setBounds(20,100,100,30);
		this.tField2.setBounds(300,100,130,30);
		this.Convert.setBounds(20, 200, 100, 50);
		this.Clear.setBounds(300,200,100,50);
	}
	
	public void launchFrame()
	{
		this.add(c1);
		this.add(c2);
		this.add(Convert);
		this.add(Clear);
		this.add(tField1);
		this.add(tField2);
		this.add(from);
		this.add(to);
		this.setVisible(true);
		
		Convert.addActionListener(this);
		Clear.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		boolean flag = false;
		// TODO Auto-generated method stub
		try
		{
			
			if(c1.getSelectedItem() == "Select One" || c2.getSelectedItem() == "Select One")
			{
				JOptionPane.showMessageDialog(this, "Please Select Unit(s)");
				flag = false;
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*1000;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*100000;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Milli Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*1000000;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Foot/Feet")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*3280.839895013123;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Inch/es")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*39370.07874015748;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Inch/es" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/39370.07874015748;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Foot/Feet" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/3280.839895013123;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Milli Metre/s" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/1000000;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/100000;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/1000;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				tField2.setText(String.valueOf(d1));flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*100;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Milli Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*1000;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Foot/Feet")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*3.280839895013123;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Inch/es")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*39.37007874015748;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				tField2.setText(String.valueOf(d1));flag = true;
			}
			if(c1.getSelectedItem() == "Inch/es" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/39.37007874015748;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Foot/Feet" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/3.280839895013123;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Milli Metre/s" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/1000;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/100;
				tField2.setText(String.valueOf(result));flag = true;
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Milli Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*10;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Foot/Feet")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*0.0328083989501312;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Inch/es")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*0.3937007874015748;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				tField2.setText(String.valueOf(d1));
			}
			if(c1.getSelectedItem() == "Milli Metre/s" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/10;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Foot/Feet" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/0.0328083989501312;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Inch/es" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/0.3937007874015748;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Foot/Feet" && c2.getSelectedItem() == "Inch/es")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*12;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Foot/Feet" && c2.getSelectedItem() == "Foot/Feet")
			{
				double d1 = Double.parseDouble(tField1.getText());
				tField2.setText(String.valueOf(d1));
				flag=true;
			}
			if(c1.getSelectedItem() == "Inch/es" && c2.getSelectedItem() == "Inch/es")
			{
				double d1 = Double.parseDouble(tField1.getText());
				tField2.setText(String.valueOf(d1));
				flag=true;
			}
			if(c1.getSelectedItem() == "Inch/es" && c2.getSelectedItem() == "Foot/Feet")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/12;
				tField2.setText(String.valueOf(result));
				flag=true;
			}
			if(c1.getSelectedItem() == "Litre/s" && c2.getSelectedItem() == "milli litre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*1000;
				tField2.setText(String.valueOf(result));
				flag=true;
			}
			if(c1.getSelectedItem() == "Litre/s" && c2.getSelectedItem() == "Litre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				tField2.setText(String.valueOf(d1));
				flag=true;
			}
			if(c1.getSelectedItem() == "milli litre/s" && c2.getSelectedItem() == "Litre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/1000;
				tField2.setText(String.valueOf(result));
				flag=true;
			}
			if(c1.getSelectedItem() == "milli litre/s" && c2.getSelectedItem() == "milli litre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				//double result = d1/1000;
				tField2.setText(String.valueOf(d1));
				flag=true;
			}
			if(c1.getSelectedItem() == "Kilo Gram/s" && c2.getSelectedItem() == "Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*1000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Kilo Gram/s" && c2.getSelectedItem() == "Milli Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*1000000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Kilo Gram/s" && c2.getSelectedItem() == "Ounce(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*35.27396194958041;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Kilo Gram/s" && c2.getSelectedItem() == "Tonne(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/1000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Kilo Gram/s" && c2.getSelectedItem() == "Kilo Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				tField2.setText(String.valueOf(d1));
			}
			if(c1.getSelectedItem() == "Gram/s" && c2.getSelectedItem() == "Kilo Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/1000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Milli Gram/s" && c2.getSelectedItem() == "Kilo Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/1000000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Gram/s" && c2.getSelectedItem() == "Milli Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*1000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Gram/s" && c2.getSelectedItem() == "Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				tField2.setText(String.valueOf(d1));
			}
			if(c1.getSelectedItem() == "Gram/s" && c2.getSelectedItem() == "Ounce(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/28.349523125;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Milli Gram/s" && c2.getSelectedItem() == "Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/1000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Milli Gram/s" && c2.getSelectedItem() == "Ounce(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/28349.523125;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Tonne(s)" && c2.getSelectedItem() == "Kilo Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*1000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Tonne(s)" && c2.getSelectedItem() == "Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*1000000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Tonne(s)" && c2.getSelectedItem() == "Milli Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*1000000000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Tonne(s)" && c2.getSelectedItem() == "Ounce(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*35273.96194958041;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Tonne(s)" && c2.getSelectedItem() == "Tonne(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				tField2.setText(String.valueOf(d1));
			}
			if(c1.getSelectedItem() == "Ounce(s)" && c2.getSelectedItem() == "Tonne(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/35273.96194958041;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Milli Gram/s" && c2.getSelectedItem() == "Tonne(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/1000000000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Gram/s" && c2.getSelectedItem() == "Tonne(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/1000000;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Ounce(s)" && c2.getSelectedItem() == "Kilo Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1/35.27396194958041;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Ounce(s)" && c2.getSelectedItem() == "Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*28.349523125;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Ounce(s)" && c2.getSelectedItem() == "Milli Gram/s")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				double result = d1*28349.523125;
				tField2.setText(String.valueOf(result));
			}
			if(c1.getSelectedItem() == "Ounce(s)" && c2.getSelectedItem() == "Ounce(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());flag = true;
				tField2.setText(String.valueOf(d1));
			}
			if(c1.getSelectedItem() == "Kilo Metre/s" && c2.getSelectedItem() == "Yard")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*1093.613298337708;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Metre/s" && c2.getSelectedItem() == "Yard")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*1.093613298337708;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Centi Metre/s" && c2.getSelectedItem() == "Yard")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/91.44;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Milli Metre/s" && c2.getSelectedItem() == "Yard")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/914.4;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Nanometer(s)" && c2.getSelectedItem() == "Yard")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/914400000;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Yard" && c2.getSelectedItem() == "Yard")
			{
				double d1 = Double.parseDouble(tField1.getText());
				tField2.setText(String.valueOf(d1));
				flag = true;
			}
			if(c1.getSelectedItem() == "Yard" && c2.getSelectedItem() == "Nanometer(s)")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*914400000;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Yard" && c2.getSelectedItem() == "Milli Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*914.4;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Yard" && c2.getSelectedItem() == "Centi Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1*91.44;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Yard" && c2.getSelectedItem() == "Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/1.093613298337708;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			if(c1.getSelectedItem() == "Yard" && c2.getSelectedItem() == "Kilo Metre/s")
			{
				double d1 = Double.parseDouble(tField1.getText());
				double result = d1/1093.613298337708;
				tField2.setText(String.valueOf(result));
				flag = true;
			}
			
			if(e.getSource() == Clear)
			{
				tField1.setText("");flag = true;
				tField2.setText("");
			}
			if(!flag)
			{
				JOptionPane.showMessageDialog(this, "Unit(s) Cannot be Converted!!!");
			}
		}
		catch(Exception exp)
		{
			JOptionPane.showMessageDialog(this, "Unit(s) Cannot be Converted!!!");
		}
	}
}
