import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class PolyGraph extends JPanel{
	JFrame frame;
	static final int SCALEFACTOR = 200;
	//static final int newCycles = 5;
	static final int size=700;
	  // int cycles;
	   String str,abc;
	   int points=SCALEFACTOR*2;   // original *2
	   int [] sines=new int[points] ;
	   int[] pts;
	   int co3val,co2val,coval;
	   
	   public PolyGraph(int x,int y,int z){
		   co3val=x*-1;
		   co2val=y*-1;
		   coval=z*-1;
		   frame = new JFrame();
		   frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		    frame.setSize(711, 700);
		    frame.setResizable(false);
		   // Diagram sines = new Diagram();
		
			frame.getContentPane().add(this);
		    frame.setVisible(true);
		    loop();

	   }
	   int x[]=new int[400];
	   public void loop(){
		   for (int i = -25; i < 24; i++)
	    	{
	   	     int radians =  i;
	   	  ///   System.out.println("pi-->"+Math.PI);
	   	  //System.out.println("S F >"+SCALEFACTOR);
	   	//System.out.println("i-->"+i);
	   	//System.out.println("radian >"+radians);
	   	     x[i+25]=radians;
	   	int y=     generateY(radians);
	   	//System.out.println("y is "+y);
	          sines[i+25] = y;
	   	    // System.out.println("from "+sines[i]);
	   	     
	   	    }
	    	repaint();
		   
	   }
	   public int generateY(int x){
		   int y=0;
		   y+=(x*x*x)*co3val;
		   y+=(x*x)*co2val;
		   y+=(x)*coval;
		   return y;
		   
		   
	   }
	   public void makeGraph(Graphics g) {
		    g.setColor(Color.lightGray);
		    // Draw grid
		    for (int y = 0; y <= size; y = y + 10) {
		    g.drawLine(1, y, size, y);
		    }
		    for (int x = 0; x <= size; x = x + 10) {
		    g.drawLine(x, 1, x, size);
		    }
		    g.setColor(Color.red);
		    // Draw y axis
		    g.drawLine(size / 2, 0, size / 2, size);
		    for (int i = 0; i <= size; i = i + 20) {
		    g.drawLine(size / 2 - 5, i, size / 2 + 5, i);
		    }
		    g.setColor(Color.red);
		    // Draw x axis
		    g.drawLine(0, size / 2, size, size / 2);
		    for (int j = 0; j <= size; j = j + 20) {
		    g.drawLine(j, size / 2 - 5, j, size / 2 + 5);
		    }
		    g.setColor(Color.black);
		    // Draw positive x axis numbers
		    for (int n = 0; n <= 10; n++) {
		      g.drawString("" + n * 2, (size / 2 - 4) + n * 40, size / 2 + 17);
		
		    }
		    // Draw negative x axis numbers
		    for (int n = 1; n <= 10; n++) {
		    g.drawString("-" + n * 2, (size / 2 - 6) - n * 40, size / 2 + 17);
		    }
		    // Draw positive y axis numbers
		    for (int n = 1; n <= 10; n++) {
		    g.drawString("" + n * 2, size / 2 - 21, (size / 2 + 5) - n * 40);
		    }
		    // Draw negative y axis numbers
		    for (int n = 1; n <= 10; n++) {
		    g.drawString("-" + n * 2, size / 2 - 23, (size / 2 + 6) + n * 40);
		    }
		    repaint();
		    }
	   public void paintComponent(Graphics g) {
		   makeGraph(g);
	  // super.paintComponent(g);
		   int maxWidth = getWidth();
		   //System.out.println(maxWidth);
	     double hstep = (double) maxWidth / (double) points;
	     int maxHeight = getHeight();
	     pts = new int[points];
	     for (int i = 0; i < 50; i++)
	       pts[i] = (int) (sines[i]);
	     g.setColor(Color.BLUE);
	     for (int i = 1; i < 50; i++) {
	    	 int x1=(int)(x[i-1])+350;
	    	 int x2=(int)(x[i])+350;
	       //int x1 = (int) ((i - 1) * hstep);
	       //int x2 = (int) (i * hstep);
	       int y1 = pts[i - 1]+350;
	       int y2 = pts[i]+350;
	      // System.out.println(i+" "+x1+" "+x2+" "+y1+" "+y2);
	    	   g.drawLine(x1, y1, x2, y2);
	     }
	   }
	   
	   
}
