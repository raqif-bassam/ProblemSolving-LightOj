import javax.swing.JFrame;


public class CalculatorFrame extends JFrame{

	  public CalculatorFrame()
      {
		  	
              setTitle("Our Scientific Calculator");
              
              CalculatorPanel calcPanel=new CalculatorPanel();
              super.setSize(700,600);
              add(calcPanel);
             // pack();
      }

}