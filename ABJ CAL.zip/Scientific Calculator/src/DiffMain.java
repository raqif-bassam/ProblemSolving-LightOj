/*
 public class DiffMain extends CalculatorPanel{
	String a;
	 public DiffMain()
	 {
		
		a="ln230x";
		
		int len,m1,m2;
		len=a.length();
		for(int i=0;i<len;i++)
		{
			//System.out.println("Char print -> "+a.charAt(i));
			if(a.charAt(i)=='c' && a.charAt(i+1)=='o' && a.charAt(i+2)=='s')
			{
				cosf(a,len);
				break;
			}
				if(a.charAt(i)=='t' && a.charAt(i+1)=='a' && a.charAt(i+2)=='n')
			{
				tanf(a,len);
				break;
			}
			//if(a.matches("sin"))
			if(a.charAt(i)=='s' && a.charAt(i+1)=='i' && a.charAt(i+2)=='n')
			{
				//System.out.println("IN SIN");
				sinf(a,len);
				break;
			}
			if(a.charAt(i)=='e')
			{
				ebase(a,len);
				break;
			}
			if(a.charAt(i)=='l' && a.charAt(i+1)=='n')
			{
				//cout<<"ln called\n";
			ln(a,len,i+2);
				
				break;
			}
			if(a.charAt(i)=='x')
			{
				normal(a,len);
				break;
			}
		}



	}

	
	

	*//**
	 * @param args
	 *//*
	public int  calc (String m,int ind,int ind1)  //add static
	{
		int j,res,c;
		res=0;
		c=1;
		for(j=ind1;j>=ind;j--)
		{
			
			res+=(m.charAt(j)-'0')*c;
			c*=10;
		}
		//System.out.println(res);
		return res;


	
	
	
	public  void normal(String a,int len) //add static
	{
		int coeff=1 , pow;
			int i=0;
			int foundx=0;
			int foundp=0;
			
			while(i<len)
				{
				if(a.charAt(i)=='x')
					{
						foundx=1;
						break;
					}
				i++;
					
				}
			
			//cout<<"found at "<<i<<endl;
			coeff=calc(a,0,i-1);
			
			
			
			if(coeff==0)
				coeff=1;
			if(foundx==0)
			{
			//	cout<<"0"<<endl;
			}
			if(a.charAt(i)=='x')
			{
				if(a.charAt(i+1)=='^' && i+1<len)
				{
					foundp=1;
					pow=calc(a,i+2,len-1);
					//System.out.println(a.charAt(i+2)+","+a.charAt(len-1));
					//System.out.println("Pow -> "+pow);
				}
				else
					pow=1;
			}
			else pow=1;
			String res="";
			if(a.charAt(0)=='x' && len==1)
			{
				res+="1";
			}
		

			else if(foundx==1 && foundp==1)
			{
				if(pow==2)
				{
					int ty=coeff*pow;
					//System.out.println(ty);
					res+=ty;
					res+="x";
					//cout<<coeff*pow<<"x"<<endl;
				}
				else if(pow==1)
				{
					int ty=coeff;
				//	System.out.println(ty);
					res+=ty;
					res+="x";
					//cout<<coeff<<"x"<<endl;
				}
				else
				{
					int ty=coeff*pow;
					//System.out.println(ty);
					res+=ty;
					res+="x^";
					ty=pow-1;
					res+=ty;
				}
				//cout<<coeff*pow<<"x^"<<pow-1<<endl;
			}
			else if(foundx==0 && foundp==0)
			{
				res+="0";
			}
			else if(foundx==1 && foundp==0)
			{
				int ty=coeff;
				//System.out.println(ty);
				res+=ty;
				
				//cout<<coeff<<endl;
			}
			System.out.println(res);
			display2.setText(res);

	}
public  void ebase(String a,int len)  //add static
	{
		String res="";
		res+=a;
		System.out.println(res);
	}
public void ln(String a,int len,int m) //add static
{
	int i,co,lo,si=0,se=0;
	String res="";
	//System.out.println("H");
	for(i=0;i<len;i++)
	{
		if(a.charAt(i)=='n')
			si=i+1;
		if(a.charAt(i)=='x')
			se=i;
	}
	int coer;
	if(si==se)
		coer=1;
	else
	coer=calc(a,si,se-1);
	if(a.charAt(0)!='l')
	{
		for(i=0;i<len;i++)
		{
		if(a.charAt(i)=='l')
			break;
		}
		
		co=calc(a,0,i-1);
		co*=coer;
		//System.out.println(co);
		lo=calc(a,i+2,len-1);
		//System.out.println(lo);
		res+=co;
		res+="/x";
		//cout<<co<<"/"<<"x"<<endl;
	}
	else
	{
		//kSystem.out.println("IN");
		//System.out.println(len);
			lo=calc(a,2,len-1);
			res+=coer;
			res+="/x";
			//cout<<"1"<<"/"<<"x"<<endl;

		

	}
	System.out.println(res);
}


public void sinf(String a,int len1)//add static
{
	int co,po,co1;
	
		int i;

		for(i=0;i<len1;i++)
		{
		if(a.charAt(i)=='s')
			break;
		}
		
		co=calc(a,0,i-1);
		//System.out.println(co);
		if(co==0)
			co=1;

	//	cout<<"co is : " <<co<<endl;

		String b="";
		int y=0;
		while(a.charAt(i)!='(')
			i++;
		i++;
		while(a.charAt(i)!=')')
		{
			b+=a.charAt(i);
			
			i++;
		}

	int	len=b.length();



		/////////////
		int coeff , pow;
		i=0;
		int foundx=0;
		int foundp=0;
		
		while(i<len)
			{
			if(b.charAt(i)=='x')
				{
					foundx=1;
					break;
				}
			i++;
				
			}
		
		
		//cout<<"found at "<<i<<endl;
		coeff=calc(b,0,i-1);
		//System.out.println("COEFF _>"+coeff);
		if(coeff==0)
			coeff=1;
		
		if(foundx==0)
		{
		//	cout<<"0"<<endl;
		}
		//System.out.println(b);
		
		//System.out.println("I is "+i);
		//System.out.println("from B "+b.charAt(i));
		if(b.charAt(i)=='x')
		{
			//System.out.println("nnnnnn");
			//System.out.println(len+"++++++ "+b.charAt(len-1));
			if(i+1<len && b.charAt(i+1)=='^')
			{	//System.out.println(" )))) "+b.charAt(i+1));		

				foundp=1;
				//System.out.println("nnnnnn "+b.charAt(i+2)+" "+b.charAt(len-1));

				pow=calc(b,i+2,len-1);
				//System.out.println("pow is ->"+pow);
			}
			else
				pow=1;
		}
		else pow=1;
		String res="";
	//	cout<<"coeff is : "<<coeff*po<<endl;
		if(b.charAt(0)=='x' && len==1)
		{
			coeff=1;
			pow=1;
		}
		 if(foundx==1 && foundp==1)
		{
			if(pow==2)
			{
				if(coeff*pow*co>1)
				{
					//System.out.println("At Block 1"+coeff+" "+pow+" "+co);
					int ty=coeff*pow*co;
					//System.out.println("At Block 1"+ty);
					res+=ty;
					res+="x";
				}
				//cout<<coeff*pow*co<<"x"<<" ";
				else
				{
					res+="x ";
				}
				//cout<<"x"<<" ";
			}
			else if(pow==1)
			{
				if(coeff*co>1)
				{
					int ty=coeff*co;
					res+=ty;
					res+="x ";
				}
				//cout<<coeff*co<<"x"<<" ";
				else
				{
					res+="x ";
				}
				//cout<<"x"<<" ";
			}
			else
			{
				
				if(coeff*pow*co>1)
				{
					int ty=coeff*co*pow;
					res+=ty;
					res+="x^";
					ty=pow-1;
					res+=ty;
					res+=" ";
				}
			//	cout<<coeff*pow*co<<"x^"<<pow-1<<" ";
				else
				{
					int ty=pow-1;
					res+="x^";
					res+=ty;
					res+=" ";
				}
					//cout<<"x^"<<pow-1<<" ";
			}
		}
	
		else if(foundx==1 && foundp==0)
		{
				if(coeff*co>1)
				{
					int ty=coeff*co;
					res+=ty;
					res+=" ";
				}
			//cout<<coeff*co<<" ";
		}


		//cout<<"cos (";
		 res+="cos (";
		for(i=0;i<len;i++)
		{
			res+=b.charAt(i);
		}
			//cout<<b[i];
		res+=")";
		//cout<<")\n";
	System.out.println(res);
}




public void cosf(String a,int len1)//add static
{
	int co,po,co1;
	
		int i;

		for(i=0;i<len1;i++)
		{
		if(a.charAt(i)=='c')
			break;
		}
		
		co=calc(a,0,i-1);
		//System.out.println(co);
		if(co==0)
			co=1;

	//	cout<<"co is : " <<co<<endl;

		String b="";
		int y=0;
		while(a.charAt(i)!='(')
			i++;
		i++;
		while(a.charAt(i)!=')')
		{
			b+=a.charAt(i);
			
			i++;
		}

	int	len=b.length();



		/////////////
		int coeff , pow;
		i=0;
		int foundx=0;
		int foundp=0;
		
		while(i<len)
			{
			if(b.charAt(i)=='x')
				{
					foundx=1;
					break;
				}
			i++;
				
			}
		
		
		//cout<<"found at "<<i<<endl;
		coeff=calc(b,0,i-1);
		//System.out.println("COEFF _>"+coeff);
		if(coeff==0)
			coeff=1;
		
		if(foundx==0)
		{
		//	cout<<"0"<<endl;
		}
		//System.out.println(b);
		
		//System.out.println("I is "+i);
		//System.out.println("from B "+b.charAt(i));
		if(b.charAt(i)=='x')
		{
			//System.out.println("nnnnnn");
			//System.out.println(len+"++++++ "+b.charAt(len-1));
			if(i+1<len && b.charAt(i+1)=='^')
			{	//System.out.println(" )))) "+b.charAt(i+1));		

				foundp=1;
				//System.out.println("nnnnnn "+b.charAt(i+2)+" "+b.charAt(len-1));

				pow=calc(b,i+2,len-1);
				//System.out.println("pow is ->"+pow);
			}
			else
				pow=1;
		}
		else pow=1;
		String res="-";
	//	cout<<"coeff is : "<<coeff*po<<endl;
		if(b.charAt(0)=='x' && len==1)
		{
			coeff=1;
			pow=1;
		}
		 if(foundx==1 && foundp==1)
		{
			if(pow==2)
			{
				if(coeff*pow*co>1)
				{
					//System.out.println("At Block 1"+coeff+" "+pow+" "+co);
					int ty=coeff*pow*co;
					//System.out.println("At Block 1"+ty);
					res+=ty;
					res+="x";
				}
				//cout<<coeff*pow*co<<"x"<<" ";
				else
				{
					res+="x ";
				}
				//cout<<"x"<<" ";
			}
			else if(pow==1)
			{
				if(coeff*co>1)
				{
					int ty=coeff*co;
					res+=ty;
					res+="x ";
				}
				//cout<<coeff*co<<"x"<<" ";
				else
				{
					res+="x ";
				}
				//cout<<"x"<<" ";
			}
			else
			{
				
				if(coeff*pow*co>1)
				{
					int ty=coeff*co*pow;
					res+=ty;
					res+="x^";
					ty=pow-1;
					res+=ty;
					res+=" ";
				}
			//	cout<<coeff*pow*co<<"x^"<<pow-1<<" ";
				else
				{
					int ty=pow-1;
					res+="x^";
					res+=ty;
					res+=" ";
				}
					//cout<<"x^"<<pow-1<<" ";
			}
		}
	
		else if(foundx==1 && foundp==0)
		{
				if(coeff*co>1)
				{
					int ty=coeff*co;
					res+=ty;
					res+=" ";
				}
			//cout<<coeff*co<<" ";
		}


		//cout<<"cos (";
		 res+="sin(";
		for(i=0;i<len;i++)
		{
			res+=b.charAt(i);
		}
			//cout<<b[i];
		res+=")";
		//cout<<")\n";
	System.out.println(res);
}


public void tanf(String a,int len1)//add static
{
	int co,po,co1;
	
		int i;

		for(i=0;i<len1;i++)
		{
		if(a.charAt(i)=='t')
			break;
		}
		
		co=calc(a,0,i-1);
		//System.out.println(co);
		if(co==0)
			co=1;

	//	cout<<"co is : " <<co<<endl;

		String b="";
		int y=0;
		while(a.charAt(i)!='(')
			i++;
		i++;
		while(a.charAt(i)!=')')
		{
			b+=a.charAt(i);
			
			i++;
		}

	int	len=b.length();



		/////////////
		int coeff , pow;
		i=0;
		int foundx=0;
		int foundp=0;
		
		while(i<len)
			{
			if(b.charAt(i)=='x')
				{
					foundx=1;
					break;
				}
			i++;
				
			}
		
		
		//cout<<"found at "<<i<<endl;
		coeff=calc(b,0,i-1);
		//System.out.println("COEFF _>"+coeff);
		if(coeff==0)
			coeff=1;
		
		if(foundx==0)
		{
		//	cout<<"0"<<endl;
		}
		//System.out.println(b);
		
		//System.out.println("I is "+i);
		//System.out.println("from B "+b.charAt(i));
		if(b.charAt(i)=='x')
		{
			//System.out.println("nnnnnn");
			//System.out.println(len+"++++++ "+b.charAt(len-1));
			if(i+1<len && b.charAt(i+1)=='^')
			{	//System.out.println(" )))) "+b.charAt(i+1));		

				foundp=1;
				//System.out.println("nnnnnn "+b.charAt(i+2)+" "+b.charAt(len-1));

				pow=calc(b,i+2,len-1);
				//System.out.println("pow is ->"+pow);
			}
			else
				pow=1;
		}
		else pow=1;
		String res="";
	//	cout<<"coeff is : "<<coeff*po<<endl;
		if(b.charAt(0)=='x' && len==1)
		{
			coeff=1;
			pow=1;
		}
		 if(foundx==1 && foundp==1)
		{
			if(pow==2)
			{
				if(coeff*pow*co>1)
				{
					//System.out.println("At Block 1"+coeff+" "+pow+" "+co);
					int ty=coeff*pow*co;
					//System.out.println("At Block 1"+ty);
					res+=ty;
					res+="x";
				}
				//cout<<coeff*pow*co<<"x"<<" ";
				else
				{
					res+="x ";
				}
				//cout<<"x"<<" ";
			}
			else if(pow==1)
			{
				if(coeff*co>1)
				{
					int ty=coeff*co;
					res+=ty;
					res+="x ";
				}
				//cout<<coeff*co<<"x"<<" ";
				else
				{
					res+="x ";
				}
				//cout<<"x"<<" ";
			}
			else
			{
				
				if(coeff*pow*co>1)
				{
					int ty=coeff*co*pow;
					res+=ty;
					res+="x^";
					ty=pow-1;
					res+=ty;
					res+=" ";
				}
			//	cout<<coeff*pow*co<<"x^"<<pow-1<<" ";
				else
				{
					int ty=pow-1;
					res+="x^";
					res+=ty;
					res+=" ";
				}
					//cout<<"x^"<<pow-1<<" ";
			}
		}
	
		else if(foundx==1 && foundp==0)
		{
				if(coeff*co>1)
				{
					int ty=coeff*co;
					res+=ty;
					res+=" ";
				}
			//cout<<coeff*co<<" ";
		}


		//cout<<"cos (";
		 res+="sec^2(";
		for(i=0;i<len;i++)
		{
			res+=b.charAt(i);
		}
			//cout<<b[i];
		res+=")";
		//cout<<")\n";
	System.out.println(res);
}
public int  calc (String m,int ind,int ind1)  //add static
{
	int j,res,c;
	res=0;
	c=1;
	for(j=ind1;j>=ind;j--)
	{
		
		res+=(m.charAt(j)-'0')*c;
		c*=10;
	}
	//System.out.println(res);
	return res;
}

	//public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="5x^2";
		int len=a.length();
		String b = "";
		b+="Name :";
		b+="Hello ";
		b+=len;
		System.out.println(b);
		
		//String a="5x^2"
	public DiffMain(){
		
		String a="ln230x";
		
		int len,m1,m2;
		len=a.length();
		for(int i=0;i<len;i++)
		{
			//System.out.println("Char print -> "+a.charAt(i));
			if(a.charAt(i)=='c' && a.charAt(i+1)=='o' && a.charAt(i+2)=='s')
			{
				cosf(a,len);
				break;
			}
				if(a.charAt(i)=='t' && a.charAt(i+1)=='a' && a.charAt(i+2)=='n')
			{
				tanf(a,len);
				break;
			}
			//if(a.matches("sin"))
			if(a.charAt(i)=='s' && a.charAt(i+1)=='i' && a.charAt(i+2)=='n')
			{
				//System.out.println("IN SIN");
				sinf(a,len);
				break;
			}
			if(a.charAt(i)=='e')
			{
				ebase(a,len);
				break;
			}
			if(a.charAt(i)=='l' && a.charAt(i+1)=='n')
			{
				//cout<<"ln called\n";
			ln(a,len,i+2);
				
				break;
			}
			if(a.charAt(i)=='x')
			{
				normal(a,len);
				break;
			}
		}



	}

}

//

//}
*/