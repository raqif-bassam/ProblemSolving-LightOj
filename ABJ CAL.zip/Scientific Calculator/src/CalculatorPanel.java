import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


	public class CalculatorPanel extends JPanel
    {		// JFrame f;
             JTextField display1;
             JTextField display2;
             JPanel buttonPanel;
            JPanel displayPanel;
            
           // private JMenuBar menubar;
            //private JMenu AdvancedCal;
            //private JMenuItem Graph,DiffMath,
           
            ActionListener listener=new CalculatorListener();
            ActionListener displayListener=new DisplayListener();
            
           
            void addDisplayButton(String type)
            {
                    JButton button=new JButton(type);
                    button.addActionListener(displayListener);
                    buttonPanel.add(button);
                   
            }
           
            void addCalcButton(String type)
            {
            	   
            	//int di=Integer.valueOf(type);
                    JButton button=new JButton(type);
                    button.addActionListener(listener);
                    if(type.equals("1"))
                    	button.setBackground(Color.cyan);
                    else  if(type.equals("2"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("3"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("4"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("5"))
                    	button.setBackground(Color.cyan);
                    else  if(type.equals("6"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("7"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("8"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("9"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("0"))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("."))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("="))
                    	button.setBackground(Color.cyan);
                    else if(type.equals("+"))
                    	button.setBackground(Color.pink);
                    else if(type.equals("-"))
                    	button.setBackground(Color.pink);
                    else if(type.equals("/"))
                    	button.setBackground(Color.pink);
                    else if(type.equals("*"))
                    	button.setBackground(Color.pink);
                    else if(type.equals("ANS"))
                    	button.setBackground(Color.cyan);
                    else
                    	button.setBackground(Color.orange);
                    
                    buttonPanel.add(button);
                   
            }
           
            public CalculatorPanel()
            {
                   
                   
                    //Layout for Main Calculator Panel
                    setLayout(new BorderLayout());
                   
                    //Display Panel
                    displayPanel=new JPanel();
                    displayPanel.setLayout(new GridLayout(2,1));
                   
                     display1=new JTextField("");
                    //display1.setBounds(0,0,200,40);
                    displayPanel.add(display1);
                   
                    display2=new JTextField("");
                    display2.setEditable(false);
                    displayPanel.add(display2);
                    //display1.requestFocusInWindow();
                   
                    add(displayPanel,BorderLayout.NORTH);
                   
                    //Panel for Buttons
                    buttonPanel=new JPanel();
                    //ButtonLayout
                    buttonPanel.setLayout(new GridLayout(7,7));
                   
                    //Button Creation
                    addCalcButton("9"); 
                    addCalcButton("8");
                    addCalcButton("7");
                    addDisplayButton("DEL");
                    addDisplayButton("AC");
                    addCalcButton("Mod");
                    addDisplayButton("OFF"); 
                    addCalcButton("6");
                    addCalcButton("5");
                    addCalcButton("4");
                    addCalcButton("*");
                    addCalcButton("/");
                    addCalcButton("Divisor");
                    addCalcButton("Cubic Root");
                    
                    addCalcButton("3");
                    addCalcButton("2");
                    addCalcButton("1");
                    addCalcButton("+");                   
                    addCalcButton("-");
                    addCalcButton("GCD");
                    addCalcButton("LCM");
                    addCalcButton("0");   
                    addCalcButton(".");
                    addCalcButton("="); 
                    addCalcButton("Is Prime");
                    addCalcButton("sin");
                    addCalcButton("cos");
                    addCalcButton("tan");
                    addCalcButton("%");
                    addCalcButton("ANS");
                    addCalcButton("PI");
                    addCalcButton("x^y");  
                    addCalcButton("sin^-1");
                    addCalcButton("cos^-1");
                    addCalcButton("tan^-1");
                    addCalcButton("(");
                    addCalcButton(")");                       
                    addCalcButton("e");
                    addCalcButton("1/x");
                    addCalcButton("x\u00B2");
                    addCalcButton("x\u00B3");
                    addCalcButton("sqrt");
                    addCalcButton("Ln");
                    addCalcButton("Lg2");
                    addCalcButton("log");                                      
                    addCalcButton("Diff");
                    addCalcButton("Base In");
                    addCalcButton("Graph");
                    addCalcButton("Conv");
                 
                    
                   // addCalcButton(",");
                    
                    
                   
                    
                   
                    
                   
                   
                    add(buttonPanel,BorderLayout.CENTER);
                   
                   
            }
           
            ScriptEngineManager manager=new ScriptEngineManager();
           ScriptEngine engine=manager.getEngineByName("JavaScript");
            boolean opDone=false;
            private class DisplayListener implements ActionListener
            {
                    public void actionPerformed(ActionEvent event)
                    {
                            String command=event.getActionCommand();
                           
                            if(command.equals("AC"))
                            {
                                    display1.setText("");
                                    display2.setText("");
                            }
                            else if(command.equals("OFF"))
                            {
                                    System.exit(0);
                            }
                            else if(command.equals("DEL"))
                            	
                            {
                            	try{
                                    display1.setText(display1.getText().substring(0, display1.getText().length()-1));
                            	}catch(Exception e){
                            		JOptionPane.showMessageDialog(null,"Nothing to delete");
                            	}
                            }
                            
                    }
            }
           
            private class CalculatorListener implements ActionListener
            {
                    public void actionPerformed (ActionEvent event)
                    {
                            String command=event.getActionCommand();

                            try{
                                    if(command.equals("log"))
                                    {
                                    	try{
                                            String d1=display1.getText();
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(Math.log10(input)));
                                            opDone=true;  
                                    
                                    }
                                    catch(NullPointerException e){
                                    	JOptionPane.showMessageDialog(null,"Please enter digit first Then Click Button\n Example : 3 log for log3");
                                    	
                                    }
                                    }
                                    else if(command.equals("cos^-1"))
                                    {
                                    	try{
                                    	double d1 = Math.acos(Double.parseDouble(display1.getText()));
                                    	display2.setText(String.valueOf(d1));
                                    	//opDone = true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first then click cos^-1 Button");
                                        		
                                    	}
                                    }
                                    else if(command.equals("sin^-1"))
                                    {
                                    	try{
                                    	double d1 = Math.asin(Double.parseDouble(display1.getText()));
                                    	display2.setText(String.valueOf(d1));
                                    	//opDone = true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first hen click sin^-1 Button");
                                        	
                                    	}
                                    }
                                    else if(command.equals("tan^-1"))
                                    {
                                    	try{
                                    	double d1 = Math.atan(Double.parseDouble(display1.getText()));
                                    	display2.setText(String.valueOf(d1));
                                    	//opDone = true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter numbers first then click tan^-1 Button");
                                        	
                                    	}
                                    }
                                    else if(command.equals("PI"))
                                    {
                                    	//String input =(display1.getText());
                                        //double d1=evaluateExpression(input);
                                    	double d1 = Math.PI;
                                    	//display1.setText(String.valueOf(d1));
                                    	display2.setText(Double.toString((d1)));
                                       // opDone=true;
                                    	//display2.setText(String.valueOf(d1));
                                    	//opDone = true;
                                    }
                                    else if(command.equals("x^y"))   /// hhhhhhhhhhhhhhhhhhhh
                                    {
                                    	try{
                                    	String m=display1.getText();
                                    	int mlen=m.length();
                                    	int n;
                                    	String b="" ;
                                    	String a="" ;
                                    	int i=0;
                                    	for(n=0;n<mlen;n++)
                                    	{
                                    		if(m.charAt(n)==',')
                                    		{
                                    			break;
                                    		}
                                    		a+=m.charAt(n);
                                    		
                                    	}
                                    	for(int j=n+1;j<mlen;j++)
                                    	{
                                    		b+=m.charAt(j);
                                    	}
                                    	
                                    	
                                    	
                                    	
                                    	int x,y;
                                    	x=Integer.valueOf(a);
                                    	y=Integer.valueOf(b);
                                    	double d1 = Math.pow(x, y);
                                    	display2.setText(String.valueOf(d1));

                                    	//opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter numbers first then click x^y Button\n NOTE: Please take input from Keyboard");
                                        	
                                    		
                                    	}
                                    	catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Enter Two numbers separated by Comma ( , )\n Example : 3,4 .Then click x^y Button\nNOTE: Please take input from Keyboard");
                                        	
                                    	}
                                    }
                                    else if(command.equals("Cubic Root"))
                                    {
                                    	try{
                                    	double d1 = Math.cbrt(Double.parseDouble(display1.getText()));
                                    	display2.setText(String.valueOf(d1));
                                    	//opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter numbers first then click Cubic Root Button");
                                        	
                                    	}
                                    }
                                    else if(command.equals("Mod"))/////jhhhh
                                    {
                                    	try{
                                    	String m=display1.getText();
                                    	int mlen=m.length();
                                    	int n;
                                    	String b="" ;
                                    	String a="" ;
                                    	int i=0;
                                    	for(n=0;n<mlen;n++)
                                    	{
                                    		if(m.charAt(n)==',')
                                    		{
                                    			break;
                                    		}
                                    		a+=m.charAt(n);
                                    		
                                    	}
                                    	for(int j=n+1;j<mlen;j++)
                                    	{
                                    		b+=m.charAt(j);
                                    	}
                                    	
                                    	
                                    	
                                    	
                                    	int x,y;
                                    	x=Integer.valueOf(a);
                                    	y=Integer.valueOf(b);
                                    	double d1 = (x%y);
                                    	display2.setText(String.valueOf(d1));

                                    	//opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter two numbers separated by Comma ( , ). \n Example: 3,4 then click Mod Button");
                                        	
                                    	}
                                    	catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter two numbers separated by Comma ( , ). \n Example: 3,4 then click Mod Button\n NOTE: Please take input from Keyboard");
                                        	
                                    	}
                                   
                                    }
                                    else if(command.equals("Lg2"))
                                    {
                                    	try{
                                    	double d1 = (Math.log10(Double.parseDouble(display1.getText())))/(Math.log10(2));
                                    	display2.setText(String.valueOf(d1));
                                    	//opDone = true;
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter number first then click Lg2 Button");
                                        			
                                    	}
                                    }
                                    else if(command.equals("Ln"))
                                    {
                                    	try{
                                    	double d1 = Math.log(Double.parseDouble(display1.getText()));
                                    	display2.setText(String.valueOf(d1));
                                    	//opDone = true;
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter number first then click Ln Button");
                                    	}
                                    }
                                    else if(command.equals("sin"))
                                    {
                                   	try{
                                            String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(Math.sin(input)));
                                            opDone=true;
                                   	}
                                   	catch(NullPointerException e){
                                   		JOptionPane.showMessageDialog(null,"Please enter digit first Then Click Button\n Example : 3 sin  for sin 3");
                                   	}
                                    }                                                                              
                                    else if(command.equals("tan"))
                                    {
                                    	try{
                                    
                                            double input=evaluateExpression(display1.getText());
                                            display2.setText(Double.toString(Math.tan(input)));
                                            opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first Then Click Button\n Example : 3 tan for tan 3");
                                    	}
                                    }
                                    else if(command.equals("cos"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(Math.cos(input)));
                                            opDone=true;
                                            //double input=evaluateExpression(display1.getText());
                                            //display2.setText(Double.toString(Math.cos(input)));                                    
                                            //opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first Then Click Button\n Example : 3 cos for cos 3");
                                    	}
                                    }                                      
                                    else if(command.equals("e"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(Math.exp(input)));
                                            opDone=true;
                                            //double input=evaluateExpression(display1.getText());
                                            //display2.setText(Double.toString(Math.exp(input)));
                                            //opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first Then Click Button\n Example : 3 e for e3");
                                    	}
                                    }                                      
                                    else if(command.equals("x\u00B2"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(input*input));
                                            opDone=true;
                                            //double input=evaluateExpression(display1.getText());
                                            //display2.setText(Double.toString(input*input));
                                            //opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first Then Click Button\n Example : 3 x^2 for 3^2");
                                    	}
                                    }                                      
                                    else if(command.equals("x\u00B3"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(input*input*input));
                                            opDone=true;
                                            //double input=evaluateExpression(display1.getText());
                                            //display2.setText(Double.toString(input*input*input));
                                            //opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first Then Click x^3 Button\n Example : 3 x^3 for 3^3");
                                    	}
                                    }      
                                    else if(command.equals("sqrt"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(Math.sqrt(input)));
                                            opDone=true;
                                            //double input=evaluateExpression(display1.getText());
                                           // display2.setText(Double.toString(Math.sqrt(input)));
                                           // opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first then Click  Button\n Example : 3 sqrt for sqrt of 3");
                                    	}
                                    }
                                    
                                    else if(command.equals("%"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(input/100));
                                            opDone=true;
                                    		//double input=evaluateExpression(display1.getText());
                                    		//display2.setText(Double.toString(input/100));
                                    		//opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit first then Click  Button\n Example : 3 % for 3%");
                                    	}
                                    }
                                    		
                                    else if(command.equals("="))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            double input=evaluateExpression(d1);
                                            display2.setText(Double.toString(input));
                                            
                                           display1.setText("");
                                           // display2.setText("");
                                            //opDone=true;
                                            //String input=display1.getText();
                                            //System.out.println(input);
                                           //display2.setText(Double.toString(input));  
                                            //opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit properly first then click button\n Example : 3 + 3 = 6");
                                    	}
                                    	catch(ArithmeticException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit properly first then click button\n Example : 3 + 3 = 6");
                                    	}
                                    	catch(Exception e)
                                    	{
                                    		JOptionPane.showMessageDialog(null,"Please enter input properly");
                                    	}
                                    }
                                    else if(command.equals("ANS"))
                                    {
                                            if(opDone)
                                            {
                                                            display1.setText(display2.getText());
                                            }
                                            else
                                            {
                                                            display1.setText(display1.getText()+display2.getText());
                                            }
                                                   
                                            opDone=false;                  
                                           
                                    }
                                    else if(command.equals("1/x"))
                                    {
                                    	try{
                                    		String d1=(display1.getText());
                                            //double input=evaluateExpression(d1);
                                            
                                            //display2.setText(Double.toString(Math.sin(input)));
                                            //opDone=true;
                                            double input=evaluateExpression(display1.getText());
                                            display2.setText(Double.toString(1/input));
                                            opDone=true;
                                    	}catch(NullPointerException e){
                                    		JOptionPane.showMessageDialog(null,"Please enter digit properly first then click button\n Example : 3,1/x for 1/3");
                                    	}
                                    }
                                    else if(command.equals("Conv")){
                                    	UnitConversion uc = new UnitConversion();
                                    	uc.launchFrame();
                                    }
                                    
                                    else if(command.equals("Base In")){
                                    	NumberSystem1 ns = new NumberSystem1();
                                    	ns.launchFrame();
                                    }
                                    else if(command.equals("LCM"))
                                    {
                                    	try{
                                    	String m=display1.getText();
                                    	int mlen=m.length();
                                    	int n;
                                    	String b="" ;
                                    	String a="" ;
                                    	int i=0;
                                    	for(n=0;n<mlen;n++)
                                    	{
                                    		if(m.charAt(n)==',')
                                    		{
                                    			break;
                                    		}
                                    		a+=m.charAt(n);
                                    		
                                    	}
                                    	for(int j=n+1;j<mlen;j++)
                                    	{
                                    		b+=m.charAt(j);
                                    	}
                                    	
                                    	
                                    	
                                    	
                                    	double x,y;
                                    	x=Double.valueOf(a);
                                    	y=Double.valueOf(b);
                                    	//calculatediv(x);
                                    	lcm(x,y);
                                    	//prime(x);
                                    	//prime(y);
                                    	//lcm(x,y);
                                    	 //opDone=true;
                                    	// display1.setText("");
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter Two numbers separated by Comma ( , ) then click LCM Button\n Example 2,3 then click LCM Button\n NOTE: Please take input from Keyboard");
                                    	}

                                    }
                                    else if(command.equals("Graph")){
                                    	new GraphCalulator();
                                    
                                    }
                                    else if(command.equals("Is Prime")){
                                    	
                                    	try{
                                    	String a=display1.getText();
                                    
                                    	int x;
                                    	x=Integer.valueOf(a);
                                    	//y=Integer.valueOf(b);
                                    	//calculatediv(x);
                                    	//gcd(x,y);
                                    	prime(x);
                                    	//prime(y);
                                    	//opDone=true;
                                    	// display1.setText("");
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter number first then click Is Prime Button");		
                                    	}
                                    }
                                    
                                    else if(command.equals("Divisor")){
                                    	try{
                                    	String a=display1.getText();
                                    	//String b="11";
                                    	
                                    	double x;
                                    	x=Double.valueOf(a);
                                    	//y=Integer.valueOf(b);
                                    	calculatediv(x);
                                    	// display1.setText(" ");
                                    	//opDone=true;
                                    	// display1.setText("");
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter number first then click Divisor Button");
                                    	}
                                    }
                                    else if(command.equals("GCD")){
                                    	try{
                                    	String m=display1.getText();
                                    	int mlen=m.length();
                                    	int n;
                                    	String b="" ;
                                    	String a="" ;
                                    	int i=0;
                                    	for(n=0;n<mlen;n++)
                                    	{
                                    		if(m.charAt(n)==',')
                                    		{
                                    			break;
                                    		}
                                    		a+=m.charAt(n);
                                    		
                                    	}
                                    	for(int j=n+1;j<mlen;j++)
                                    	{
                                    		b+=m.charAt(j);
                                    	}
                                    	
                                    	
                                    	
                                    	
                                    	double x,y;
                                    	x=Double.valueOf(a);
                                    	y=Double.valueOf(b);
                                    	//calculatediv(x);
                                    	gcd(x,y);
                                    	//prime(x);
                                    	//prime(y);
                                    	//lcm(x,y);

                                    	//opDone=true;
                                    	// display1.setText("");
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter Two numbers separated by comma ( , ). \n Example: 3,5 then click GCD Button");
                                    	}
                                    }
                                    else if(command.equals("Diff"))
                                    {
                                    	try{
                                    	
                                    	String a=display1.getText();
                                		System.out.println(a);
                                		
                                		int len,m1,m2;
                                		len=a.length();
                                		System.out.println(len);
                                		for(int i=0;i<len;i++)
                                		{
                                			//System.out.println("Char print -> "+a.charAt(i));
                                			if(a.charAt(i)=='c' && a.charAt(i+1)=='o' && a.charAt(i+2)=='s')
                                			{
                                				cosf(a,len);
                                				break;
                                			}
                                				if(a.charAt(i)=='t' && a.charAt(i+1)=='a' && a.charAt(i+2)=='n')
                                			{
                                				tanf(a,len);
                                				break;
                                			}
                                			//if(a.matches("sin"))
                                			if(a.charAt(i)=='s' && a.charAt(i+1)=='i' && a.charAt(i+2)=='n')
                                			{
                                				//System.out.println("IN SIN");
                                				sinf(a,len);
                                				break;
                                			}
                                			if(a.charAt(i)=='e')
                                			{
                                				ebase(a,len);
                                				break;
                                			}
                                			if(a.charAt(i)=='l' && a.charAt(i+1)=='n')
                                			{
                                				//cout<<"ln called\n";
                                			ln(a,len,i+2);
                                				
                                				break;
                                			}
                                			if(a.charAt(i)=='x')
                                			{
                                				normal(a,len);
                                				break;
                                			}
                                		}
                                    	}catch(Exception e){
                                    		JOptionPane.showMessageDialog(null,"Please enter number first then click Differentiate Button: NOTE: Please take inpute from Keyboard");
                                    	}
                                		
                                    	
                                    }
                                    
                                    	
                                 
                                    else
                                    {
                                            char opr=command.charAt(0);
                                            if(opDone)
                                            {
                                                    if(Character.isDigit(opr)||opr=='.')
                                                    {
                                                            display1.setText(command);
                                                    }
                                                    else
                                                            display1.setText(display2.getText()+command);
                                            }
                                            else
                                                    display1.setText(display1.getText()+command);
                                          // opDone=true;    
                                            //display1.setText("");
                                    }
                                   
                                    
                   
                                    
                                    
                            }
                            
                           catch (Exception ex)
                            {
                                    JOptionPane.showMessageDialog(null, "Please Check the Syntax Properly");
                           }

                           
                    }
                   
                    Double evaluateExpression (String expression) throws Exception
                   {      
                            //System.out.println(expression);
                           return (Double) engine.eval(expression);
                    }
            }
            
           
            public int  calc (String m,int ind,int ind1)
        	{
        		int j,res,c;
        		res=0;
        		c=1;
        		for(j=ind1;j>=ind;j--)
        		{
        			
        			res+=(m.charAt(j)-'0')*c;
        			c*=10;
        		}
        		//System.out.println(res);
        		return res;


        	}
        	
        	
        	public void normal(String a,int len)
        	{
        		int coeff=1 , pow;
        			int i=0;
        			int foundx=0;
        			int foundp=0;
        			
        			while(i<len)
        				{
        				if(a.charAt(i)=='x')
        					{
        						foundx=1;
        						break;
        					}
        				i++;
        					
        				}
        			
        			//cout<<"found at "<<i<<endl;
        			coeff=calc(a,0,i-1);
        			
        			
        			
        			if(coeff==0)
        				coeff=1;
        			if(foundx==0)
        			{
        			//	cout<<"0"<<endl;
        			}
        			if(a.charAt(i)=='x')
        			{
        				if(i+1<len-1 && a.charAt(i+1)=='^' )
        				{
        					foundp=1;
        					pow=calc(a,i+2,len-1);
        					//System.out.println(a.charAt(i+2)+","+a.charAt(len-1));
        					//System.out.println("Pow -> "+pow);
        				}
        				else
        					pow=1;
        			}
        			else pow=1;
        			String res="";
        			if(a.charAt(0)=='x' && len==1)
        			{
        				res+="1";
        			}
        		

        			else if(foundx==1 && foundp==1)
        			{
        				if(pow==2)
        				{
        					int ty=coeff*pow;
        					//System.out.println(ty);
        					res+=ty;
        					res+="x";
        					//cout<<coeff*pow<<"x"<<endl;
        				}
        				else if(pow==1)
        				{
        					int ty=coeff;
        				//	System.out.println(ty);
        					res+=ty;
        					res+="x";
        					//cout<<coeff<<"x"<<endl;
        				}
        				else
        				{
        					int ty=coeff*pow;
        					//System.out.println(ty);
        					res+=ty;
        					res+="x^";
        					ty=pow-1;
        					res+=ty;
        				}
        				//cout<<coeff*pow<<"x^"<<pow-1<<endl;
        			}
        			else if(foundx==0 && foundp==0)
        			{
        				res+="0";
        			}
        			else if(foundx==1 && foundp==0)
        			{
        				int ty=coeff;
        				//System.out.println(ty);
        				res+=ty;
        				
        				//cout<<coeff<<endl;
        			}
        			//System.out.println(res);
        			display2.setText(res);

        	}
        public  void ebase(String a,int len)
        	{
        		String res="";
        		res+=a;
        		//System.out.println(res);
        		display2.setText(res);
        	}
        public  void ln(String a,int len,int m)
        {
        	int i,co,lo,si=0,se=0;
        	String res="";
        	//System.out.println("H");
        	for(i=0;i<len;i++)
        	{
        		if(a.charAt(i)=='n')
        			si=i+1;
        		if(a.charAt(i)=='x')
        			se=i;
        	}
        	int coer;
        	if(si==se)
        		coer=1;
        	else
        	coer=calc(a,si,se-1);
        	if(a.charAt(0)!='l')
        	{
        		for(i=0;i<len;i++)
        		{
        		if(a.charAt(i)=='l')
        			break;
        		}
        		
        		co=calc(a,0,i-1);
        		co*=coer;
        		//System.out.println(co);
        		lo=calc(a,i+2,len-1);
        		//System.out.println(lo);
        		res+=co;
        		res+="/x";
        		//cout<<co<<"/"<<"x"<<endl;
        	}
        	else
        	{
        		//kSystem.out.println("IN");
        		//System.out.println(len);
        			lo=calc(a,2,len-1);
        			res+=coer;
        			res+="/x";
        			//cout<<"1"<<"/"<<"x"<<endl;

        		

        	}
        	//System.out.println(res);
        	display2.setText(res);
        }


        public void sinf(String a,int len1)
        {
        	int co,po,co1;
        	
        		int i;

        		for(i=0;i<len1;i++)
        		{
        		if(a.charAt(i)=='s')
        			break;
        		}
        		
        		co=calc(a,0,i-1);
        		//System.out.println(co);
        		if(co==0)
        			co=1;

        	//	cout<<"co is : " <<co<<endl;

        		String b="";
        		int y=0;
        		while(a.charAt(i)!='(')
        			i++;
        		i++;
        		while(a.charAt(i)!=')')
        		{
        			b+=a.charAt(i);
        			
        			i++;
        		}

        	int	len=b.length();



        		/////////////
        		int coeff , pow;
        		i=0;
        		int foundx=0;
        		int foundp=0;
        		
        		while(i<len)
        			{
        			if(b.charAt(i)=='x')
        				{
        					foundx=1;
        					break;
        				}
        			i++;
        				
        			}
        		
        		
        		//cout<<"found at "<<i<<endl;
        		coeff=calc(b,0,i-1);
        		//System.out.println("COEFF _>"+coeff);
        		if(coeff==0)
        			coeff=1;
        		
        		if(foundx==0)
        		{
        		//	cout<<"0"<<endl;
        		}
        		//System.out.println(b);
        		
        		//System.out.println("I is "+i);
        		//System.out.println("from B "+b.charAt(i));
        		if(b.charAt(i)=='x')
        		{
        			//System.out.println("nnnnnn");
        			//System.out.println(len+"++++++ "+b.charAt(len-1));
        			if(i+1<len && b.charAt(i+1)=='^')
        			{	//System.out.println(" )))) "+b.charAt(i+1));		

        				foundp=1;
        				//System.out.println("nnnnnn "+b.charAt(i+2)+" "+b.charAt(len-1));

        				pow=calc(b,i+2,len-1);
        				//System.out.println("pow is ->"+pow);
        			}
        			else
        				pow=1;
        		}
        		else pow=1;
        		String res="";
        	//	cout<<"coeff is : "<<coeff*po<<endl;
        		if(b.charAt(0)=='x' && len==1)
        		{
        			coeff=1;
        			pow=1;
        		}
        		 if(foundx==1 && foundp==1)
        		{
        			if(pow==2)
        			{
        				if(coeff*pow*co>1)
        				{
        					//System.out.println("At Block 1"+coeff+" "+pow+" "+co);
        					int ty=coeff*pow*co;
        					//System.out.println("At Block 1"+ty);
        					res+=ty;
        					res+="x";
        				}
        				//cout<<coeff*pow*co<<"x"<<" ";
        				else
        				{
        					res+="x ";
        				}
        				//cout<<"x"<<" ";
        			}
        			else if(pow==1)
        			{
        				if(coeff*co>1)
        				{
        					int ty=coeff*co;
        					res+=ty;
        					res+="x ";
        				}
        				//cout<<coeff*co<<"x"<<" ";
        				else
        				{
        					res+="x ";
        				}
        				//cout<<"x"<<" ";
        			}
        			else
        			{
        				
        				if(coeff*pow*co>1)
        				{
        					int ty=coeff*co*pow;
        					res+=ty;
        					res+="x^";
        					ty=pow-1;
        					res+=ty;
        					res+=" ";
        				}
        			//	cout<<coeff*pow*co<<"x^"<<pow-1<<" ";
        				else
        				{
        					int ty=pow-1;
        					res+="x^";
        					res+=ty;
        					res+=" ";
        				}
        					//cout<<"x^"<<pow-1<<" ";
        			}
        		}
        	
        		else if(foundx==1 && foundp==0)
        		{
        				if(coeff*co>1)
        				{
        					int ty=coeff*co;
        					res+=ty;
        					res+=" ";
        				}
        			//cout<<coeff*co<<" ";
        		}


        		//cout<<"cos (";
        		 res+="cos (";
        		for(i=0;i<len;i++)
        		{
        			res+=b.charAt(i);
        		}
        			//cout<<b[i];
        		res+=")";
        		//cout<<")\n";
        	//System.out.println(res);
        		display2.setText(res);
        }




        public void cosf(String a,int len1)
        {
        	int co,po,co1;
        	
        		int i;

        		for(i=0;i<len1;i++)
        		{
        		if(a.charAt(i)=='c')
        			break;
        		}
        		
        		co=calc(a,0,i-1);
        		//System.out.println(co);
        		if(co==0)
        			co=1;

        	//	cout<<"co is : " <<co<<endl;

        		String b="";
        		int y=0;
        		while(a.charAt(i)!='(')
        			i++;
        		i++;
        		while(a.charAt(i)!=')')
        		{
        			b+=a.charAt(i);
        			
        			i++;
        		}

        	int	len=b.length();



        		/////////////
        		int coeff , pow;
        		i=0;
        		int foundx=0;
        		int foundp=0;
        		
        		while(i<len)
        			{
        			if(b.charAt(i)=='x')
        				{
        					foundx=1;
        					break;
        				}
        			i++;
        				
        			}
        		
        		
        		//cout<<"found at "<<i<<endl;
        		coeff=calc(b,0,i-1);
        		//System.out.println("COEFF _>"+coeff);
        		if(coeff==0)
        			coeff=1;
        		
        		if(foundx==0)
        		{
        		//	cout<<"0"<<endl;
        		}
        		//System.out.println(b);
        		
        		//System.out.println("I is "+i);
        		//System.out.println("from B "+b.charAt(i));
        		if(b.charAt(i)=='x')
        		{
        			//System.out.println("nnnnnn");
        			//System.out.println(len+"++++++ "+b.charAt(len-1));
        			if(i+1<len && b.charAt(i+1)=='^')
        			{	//System.out.println(" )))) "+b.charAt(i+1));		

        				foundp=1;
        				//System.out.println("nnnnnn "+b.charAt(i+2)+" "+b.charAt(len-1));

        				pow=calc(b,i+2,len-1);
        				//System.out.println("pow is ->"+pow);
        			}
        			else
        				pow=1;
        		}
        		else pow=1;
        		String res="-";
        	//	cout<<"coeff is : "<<coeff*po<<endl;
        		if(b.charAt(0)=='x' && len==1)
        		{
        			coeff=1;
        			pow=1;
        		}
        		 if(foundx==1 && foundp==1)
        		{
        			if(pow==2)
        			{
        				if(coeff*pow*co>1)
        				{
        					//System.out.println("At Block 1"+coeff+" "+pow+" "+co);
        					int ty=coeff*pow*co;
        					//System.out.println("At Block 1"+ty);
        					res+=ty;
        					res+="x";
        				}
        				//cout<<coeff*pow*co<<"x"<<" ";
        				else
        				{
        					res+="x ";
        				}
        				//cout<<"x"<<" ";
        			}
        			else if(pow==1)
        			{
        				if(coeff*co>1)
        				{
        					int ty=coeff*co;
        					res+=ty;
        					res+="x ";
        				}
        				//cout<<coeff*co<<"x"<<" ";
        				else
        				{
        					res+="x ";
        				}
        				//cout<<"x"<<" ";
        			}
        			else
        			{
        				
        				if(coeff*pow*co>1)
        				{
        					int ty=coeff*co*pow;
        					res+=ty;
        					res+="x^";
        					ty=pow-1;
        					res+=ty;
        					res+=" ";
        				}
        			//	cout<<coeff*pow*co<<"x^"<<pow-1<<" ";
        				else
        				{
        					int ty=pow-1;
        					res+="x^";
        					res+=ty;
        					res+=" ";
        				}
        					//cout<<"x^"<<pow-1<<" ";
        			}
        		}
        	
        		else if(foundx==1 && foundp==0)
        		{
        				if(coeff*co>1)
        				{
        					int ty=coeff*co;
        					res+=ty;
        					res+=" ";
        				}
        			//cout<<coeff*co<<" ";
        		}


        		//cout<<"cos (";
        		 res+="sin(";
        		for(i=0;i<len;i++)
        		{
        			res+=b.charAt(i);
        		}
        			//cout<<b[i];
        		res+=")";
        		//cout<<")\n";
        	//System.out.println(res);
        		display2.setText(res);
        }


        public void tanf(String a,int len1)
        {
        	int co,po,co1;
        	
        		int i;

        		for(i=0;i<len1;i++)
        		{
        		if(a.charAt(i)=='t')
        			break;
        		}
        		
        		co=calc(a,0,i-1);
        		//System.out.println(co);
        		if(co==0)
        			co=1;

        	//	cout<<"co is : " <<co<<endl;

        		String b="";
        		int y=0;
        		while(a.charAt(i)!='(')
        			i++;
        		i++;
        		while(a.charAt(i)!=')')
        		{
        			b+=a.charAt(i);
        			
        			i++;
        		}

        	int	len=b.length();



        		/////////////
        		int coeff , pow;
        		i=0;
        		int foundx=0;
        		int foundp=0;
        		
        		while(i<len)
        			{
        			if(b.charAt(i)=='x')
        				{
        					foundx=1;
        					break;
        				}
        			i++;
        				
        			}
        		
        		
        		//cout<<"found at "<<i<<endl;
        		coeff=calc(b,0,i-1);
        		//System.out.println("COEFF _>"+coeff);
        		if(coeff==0)
        			coeff=1;
        		
        		if(foundx==0)
        		{
        		//	cout<<"0"<<endl;
        		}
        		//System.out.println(b);
        		
        		//System.out.println("I is "+i);
        		//System.out.println("from B "+b.charAt(i));
        		if(b.charAt(i)=='x')
        		{
        			//System.out.println("nnnnnn");
        			//System.out.println(len+"++++++ "+b.charAt(len-1));
        			if(i+1<len && b.charAt(i+1)=='^')
        			{	//System.out.println(" )))) "+b.charAt(i+1));		

        				foundp=1;
        				//System.out.println("nnnnnn "+b.charAt(i+2)+" "+b.charAt(len-1));

        				pow=calc(b,i+2,len-1);
        				//System.out.println("pow is ->"+pow);
        			}
        			else
        				pow=1;
        		}
        		else pow=1;
        		String res="";
        	//	cout<<"coeff is : "<<coeff*po<<endl;
        		if(b.charAt(0)=='x' && len==1)
        		{
        			coeff=1;
        			pow=1;
        		}
        		 if(foundx==1 && foundp==1)
        		{
        			if(pow==2)
        			{
        				if(coeff*pow*co>1)
        				{
        					//System.out.println("At Block 1"+coeff+" "+pow+" "+co);
        					int ty=coeff*pow*co;
        					//System.out.println("At Block 1"+ty);
        					res+=ty;
        					res+="x";
        				}
        				//cout<<coeff*pow*co<<"x"<<" ";
        				else
        				{
        					res+="x ";
        				}
        				//cout<<"x"<<" ";
        			}
        			else if(pow==1)
        			{
        				if(coeff*co>1)
        				{
        					int ty=coeff*co;
        					res+=ty;
        					res+="x ";
        				}
        				//cout<<coeff*co<<"x"<<" ";
        				else
        				{
        					res+="x ";
        				}
        				//cout<<"x"<<" ";
        			}
        			else
        			{
        				
        				if(coeff*pow*co>1)
        				{
        					int ty=coeff*co*pow;
        					res+=ty;
        					res+="x^";
        					ty=pow-1;
        					res+=ty;
        					res+=" ";
        				}
        			//	cout<<coeff*pow*co<<"x^"<<pow-1<<" ";
        				else
        				{
        					int ty=pow-1;
        					res+="x^";
        					res+=ty;
        					res+=" ";
        				}
        					//cout<<"x^"<<pow-1<<" ";
        			}
        		}
        	
        		else if(foundx==1 && foundp==0)
        		{
        				if(coeff*co>1)
        				{
        					int ty=coeff*co;
        					res+=ty;
        					res+=" ";
        				}
        			//cout<<coeff*co<<" ";
        		}


        		//cout<<"cos (";
        		 res+="sec^2(";
        		for(i=0;i<len;i++)
        		{
        			res+=b.charAt(i);
        		}
        			//cout<<b[i];
        		res+=")";
        		//cout<<")\n";
        	//System.out.println(res);
        		display2.setText(res);
        }
        
        public void calculatediv(Double x)
    	{
    		
    		
    			
    			String m="";
    			int i,temp,t;
    			int n=0;
    			int found=0;
    			for(i=2;i<=x/2;i++)
    			{

    				if(x%i==0)
    				{
    					if(n!=0)
    						m+=",";
    					if(n==0)
    						n=1;
    					
    					
    					found=1;
    					m+=i;
    					
    					
    						
    					
    				}
    			}
    				
    				if(found==0)
    				m+="No Divisor.";
    			//System.out.println(m);
    				display2.setText(m);
    			
    		}
        public void prime(int x)
    	{
    		String res="";
    		if(x<=1)
    		{
    			res+="Not Prime";
    			
    		}
    		else
    		{
    		int i,temp=0;
    		for(i=2;i<=Math.sqrt(x);i++)
    		{
    			if(x%i==0)
    			{
    				temp=1;
    				break;
    			}
    		}
    		if(temp==0)
    			res+="Prime";
    		else
    			res+="Not Prime";
    		}
    		//System.out.println(res);
    		display2.setText(res);
    	}
    	public double gcd_recurse(double a, double b)
    	{
    	double temp;

    	temp = a % b;

    	if (temp == 0)
    	{
    	return(b);
    	}
    	else
    	{
    	return(gcd_recurse(b, temp));
    	}
    	}
        public void gcd(double x,double y)
    	{
    		double gcd=gcd_recurse(x,y);
    		//	int lcm=(x*y)/gcd;
    		int ans=(int)gcd;
    		String res="";
    		res+=ans;  //origin gcd
    		//System.out.println(res);
    		display2.setText(res);
    	}
        public  void lcm(double x,double y)
    	{
    		double gcd=gcd_recurse(x,y);
    		double lcm=(x*y)/gcd;
    		int ans2=(int)lcm;
    		String res="";
    		res+=ans2;    //origin lcm
     		
    		//System.out.println(res);
    		display2.setText(res);
    	}
            

}
