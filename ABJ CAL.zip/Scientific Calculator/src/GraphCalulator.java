import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.jar.JarOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;



public class GraphCalulator extends JFrame{
	
	JFrame frame;
	//JPanel leftpanel,rightpanel,panel1;

	JTextField eqn;
	JLabel lblY;
	JButton graph;
	JLabel lblA,lblB,lblC;
	JTextField txtA,txtB,txtC;
	JButton btndraw;
	String co3;
	String co2;
	String co;
	Integer co3val,co2val,coval;
	
	
	public GraphCalulator()
	{
		frame=new JFrame("Graphical Calculator");
		frame.setSize(550,200);
		frame.setVisible(true);
		frame.setLayout(null);
		frame.setResizable(false);
		addComponent();
		frame.setVisible(true);
		
	}
	public void addComponent(){
		
		
		lblY=new JLabel("Y= ");
		lblA=new JLabel("X^3");
		lblB=new JLabel("X^2");
		lblC=new JLabel("X");
		txtA=new JTextField();
		txtB=new JTextField();
		txtC=new JTextField();
		txtA.setText("0");
		txtB.setText("0");
		txtC.setText("0");
		graph=new JButton("Polynomial Graph");
		
		lblA.setBounds(10,10, 30,30);
		txtA.setBounds(40, 10,70,30);
		lblB.setBounds(120,10,70 ,30);
		txtB.setBounds(160,10,70,30);
		lblC.setBounds(260,10,30,30);
		txtC.setBounds(280,10,70,30);
		graph.setBounds(360,10,140,20);
		
		frame.add(txtA);
		frame.add(txtB);
		frame.add(txtC);
		frame.add(lblA);
		frame.add(lblB);
		frame.add(lblC);
		frame.add(graph);
		
		lblY.setBounds(10,70,40,30);
		frame.add(lblY);
		eqn=new JTextField();
		eqn.setBounds(40,70,200,30);
		frame.add(eqn);
		btndraw=new JButton("Trigonometric Graph");
		btndraw.setBounds(270,70,170,30);
		graph.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try{
				co3=txtA.getText();
				co2=txtB.getText();
				co=txtC.getText();
				co3val=Integer.parseInt(co3);
				co2val=Integer.valueOf(co2);
				coval=Integer.valueOf(co);
				System.out.println(""+co3val);
				
				new PolyGraph(co3val,co2val,coval);
				}catch(Exception e){
					JOptionPane.showMessageDialog(null,"Please fill unused TextFiels with Zeros ");
				}
				
			}
			
		});
		btndraw.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String x=eqn.getText();

				new Graph(x);
			
				
			}
			
		});
		frame.add(btndraw);
		}
	
	
	}

