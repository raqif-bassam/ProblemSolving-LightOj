import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Graph extends JPanel{
	
	static final int SCALEFACTOR = 200;
	static final int newCycles = 5;
	static final int size=670;   //700
	   int cycles;
	   String str,abc;
	   int points;
	   double[] sines;
	   int[] pts;
	   
	   
	   
	   public Graph(String x) {
		   
		    str=x;
		   JFrame frame = new JFrame();
		    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		    frame.setSize(678, 700);
		    frame.setResizable(false);
		   // Diagram sines = new Diagram();
			setCycles(5,str);
			frame.getContentPane().add(this);
		    frame.setVisible(true);
	   }
	   public  void setCycles(int newCycles,String str) {
		   abc=str;
		   //System.out.println("I am reached "+abc);
	     cycles = newCycles;
	     points = SCALEFACTOR * cycles * 2;
	     sines = new double[points];
	    // System.out.println("Inside try block "+abc);
	     if(abc.equals("sin(x)"))
	     {
	    	
	    	//System.out.println("I am points "+points);
	    	for (int i = 0; i < points; i++)
	    	{
	   	     double radians = (Math.PI / SCALEFACTOR) * i;
	   	     //System.out.println(radians);
	   	     sines[i] = Math.sin(radians);
	   	 // repaint();  // original: place rapint in out of loop
	   	    }
	    	repaint();
	     }
	     else if(abc.equals("cos(x)"))
	     {
	    	 for (int i = 0; i < points; i++)
	    	 {
		     double radians = (Math.PI / SCALEFACTOR) * i;
	    	 sines[i] = Math.cos(radians);
	    	 }
	    	 repaint();
	     }
	     else if(abc.equals("tan(x)")){
	    	 for (int i = 0; i < points; i++) 
	    	 {
	    	     double radians = (Math.PI / SCALEFACTOR) * i;
	    	 sines[i] = Math.tan(radians);
	    	 }
	    	 repaint();
	     }
	    
	     }//catch(Exception e){
	    	 //System.out.println("Some thing wrong");
	    	 
	     //}..................................................
	   
	   public void makeGraph(Graphics g) {
		    g.setColor(Color.lightGray);
		    // Draw grid
		    for (int y = 0; y <= 770; y = y + 10) {  // y==size
		    g.drawLine(1, y, 770, y);
		    }
		    for (int x = 0; x <=770; x = x + 10) {   // x==size
		    g.drawLine(x,1, x, 770);  //interchange 1 and x
		    }
		    g.setColor(Color.red);
		    // Draw y axis
		    g.drawLine(size / 2, 0, size / 2, size);
		    for (int i = 0; i <= size; i = i + 20) {
		    g.drawLine(size / 2 - 5, i, size / 2 + 5, i);
		    }
		    g.setColor(Color.red);
		    // Draw x axis
		    g.drawLine(0, size /2, size, size /2);   // 2nd para-> size/2
		    for (int j = 0; j <= size; j = j + 20) {
		    g.drawLine(j, size / 2 -5, j, size / 2 + 5);  // size/2-5
		    }
		    g.setColor(Color.black);
		    // Draw positive x axis numbers
		    for (int n = 0; n <= 10; n++) {
		      g.drawString("" + n * 2, (size / 2 - 4) + n * 40, size / 2 + 17);
		
		    }
		    // Draw negative x axis numbers
		    for (int n = 1; n <= 10; n++) {
		    g.drawString("-" + n * 2, (size / 2 - 6) - n * 40, size / 2 + 17);
		    }
		    // Draw positive y axis numbers
		    for (int n = 1; n <= 10; n++) {
		    g.drawString("" + n * 2, size / 2 - 21, (size / 2 + 5) - n * 40);
		    }
		    // Draw negative y axis numbers
		    for (int n = 1; n <= 10; n++) {
		    g.drawString("-" + n * 2, size / 2 - 23, (size / 2 + 6) + n * 40);
		    }
		    repaint();
		    }
	    
	   public void paintComponent(Graphics g) {
		   makeGraph(g);
	    // super.paintComponent(g);
	     int maxWidth = getWidth();
		  //System.out.println("Max Mwight "+maxWidth);
	     double hstep = (double) maxWidth / (double) points;
	    // System.out.println("hstep "+hstep);
	     int maxHeight = getHeight();
	    // System.out.println("Max Height "+maxHeight);
	     pts = new int[points];
	     for (int i = 0; i < points; i++)
	     {
	       pts[i] = (int) (sines[i] * maxHeight /2*0.95 + (maxHeight /2));  // add 2* 0.95 after 2   // /2 in maxW
	       		//if(i<5)
	    	  //System.out.println("Pts"+i+" is "+pts[i]);
	     }
	     
	     g.setColor(Color.BLUE);
	     for (int i = 1; i < points; i++) {
	       int x1 = (int) ((i - 1) * hstep);
	       int x2 = (int) (i * hstep);
	       int y1 = pts[i - 1];
	       int y2 = pts[i];
	       g.drawLine(x1, y1, x2, y2);
	     }
	   }
	 

}
