import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class NumberSystem1 extends JFrame implements ActionListener {
	
	
	char o;
	int ctr=0;
	String value="", cv="", oBtn;
	double answer=0, v1, v2,r2;
	int NumberConverted;int bv1,bv2,banswer,bNumberConverted;

	JPanel p1, p2, p3, p4, p5, p6, p7,p8;
	JTextField tField;
	JRadioButton Dec,Bin,Hex,Oct;
	JButton num0, num1, num2, num3, num4, num5, num6, num7, num8,num9, A, B, C, D, E, F; 
	JButton bAdd, bSub, bMul, bDiv, bInt, bCE, equals, backspace, clear;
	//int temp ;
	public NumberSystem1(){
			this.setTitle("Calculator");
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setLocationRelativeTo(null);


			p1 = new JPanel();
			p2 = new JPanel();
			p3 = new JPanel();
			p4 = new JPanel();
			p5 = new JPanel();
			p6 = new JPanel();
			p7 = new JPanel();
			p8 = new JPanel();
			
			tField = new JTextField(35);
			Bin = new JRadioButton("Binary");
			Dec = new JRadioButton("Decimal");
			Hex = new JRadioButton("HexaDecimal");
			Oct = new JRadioButton("Octal");

			A = new JButton ("A");
			B = new JButton ("B");
			C = new JButton ("C");
			D = new JButton ("D");
			E = new JButton ("E");
			F = new JButton ("F");
			num0 = new JButton 	("0");
			num1 = new JButton 	("1");
			num2 = new JButton 	("2");
			num3 = new JButton 	("3");
			num4 = new JButton 	("4");
			num5 = new JButton 	("5");
			num6 = new JButton 	("6");
			num7 = new JButton 	("7");
			num8 = new JButton 	("8");
			num9 = new JButton 	("9");
			bAdd = new JButton 	("+");
			bSub = new JButton 	("-");
			bMul = new JButton 	("x");
			bDiv = new JButton 	("/");
			bInt = new JButton 	("+/-");
			bCE = new JButton 	("CE");
			equals = new JButton 	("=");
			backspace = new JButton 	("Backspace");
			clear = new JButton	("C");
	}
		
	
		public void launchFrame(){

			tField.setText("0");
			tField.setEditable(false);
			this.Dec.setSelected(true);
			
			this.A.setEnabled(false); this.B.setEnabled(false); this.C.setEnabled(false); this.D.setEnabled(false); 
			this.E.setEnabled(false); this.F.setEnabled(false);
			
			p1.add(Bin);
			p1.add(Dec);
			p1.add(Hex);
			p1.add(Oct);
			
			p2.add(backspace);
			p2.add(bCE);
			p2.add(clear);

			p3.add(num7);
			p3.add(num8);
			p3.add(num9);
			p3.add(bDiv);

			p4.add(num4);
			p4.add(num5);
			p4.add(num6);
			p4.add(bMul);

			p5.add(num1);
			p5.add(num2);
			p5.add(num3);
			p5.add(bSub);

			p6.add(num0);
			p6.add(bInt);
			p6.add(bAdd);
			p6.add(equals);
			
			p7.add(A);
			p7.add(B);
			p7.add(C);
			p7.add(D);
			
			p8.add(E);
			p8.add(F);
			
			p2.setLayout(new GridLayout (1, 3, 2, 2) );
			p3.setLayout(new GridLayout (1, 3, 2, 2) );
			p4.setLayout(new GridLayout (1, 3, 2, 2) );
			p5.setLayout(new GridLayout (1, 3, 2, 2) );
			p6.setLayout(new GridLayout (1, 3, 2, 2) );
			p7.setLayout(new GridLayout (1, 3, 2, 2) );
			p8.setLayout(new GridLayout (1, 3, 2, 2) );

			this.setLayout(new GridLayout (9,1) );
			this.setResizable(false);
			this.setSize(300,250);
			this.add(p1);
			this.add(tField);
			this.add(p2);
			this.add(p3);
			this.add(p4);
			this.add(p5);
			this.add(p6);
			this.add(p7);
			this.add(p8);
			this.setVisible(true);
			
			this.pack();

		// ACTION LISTENERS
			clear.addActionListener(this);
			bCE.addActionListener(this);

			num0.addActionListener(this);
			num1.addActionListener(this);
			num2.addActionListener(this);
			num3.addActionListener(this);
			num4.addActionListener(this);
			num5.addActionListener(this);
			num6.addActionListener(this);
			num7.addActionListener(this);
			num8.addActionListener(this);
			num9.addActionListener(this);
			A.addActionListener(this);
			B.addActionListener(this);
			C.addActionListener(this);
			D.addActionListener(this);
			E.addActionListener(this);
			F.addActionListener(this);

			bAdd.addActionListener(this);
			bSub.addActionListener(this);
			bMul.addActionListener(this);
			bDiv.addActionListener(this);


			bInt.addActionListener(this);

			Bin.addActionListener(this);
			Dec.addActionListener(this);
			Hex.addActionListener(this);
			Oct.addActionListener(this);
			
			equals.addActionListener(this);
			backspace.addActionListener(this);

			
			
		}

		
		
		int d1=0,s1=0;
	
		public void actionPerformed(final ActionEvent a){
		//temp = Integer.valueOf(tField.getText());
		try{
			if(a.getSource()==num0){
				value+=0;
				tField.setText(value);
			}
			if(a.getSource()==num1){
				value+=1;
				tField.setText(value);
			}
			if(a.getSource()==num2){
				value+=2;
				tField.setText(value);
			}
			if(a.getSource()==num3){
				value+=3;
				tField.setText(value);
			}
			if(a.getSource()==num4){
				value+=4;
				tField.setText(value);
			}
			if(a.getSource()==num5){
				value+=5;
				tField.setText(value);
			}
			if(a.getSource()==num6){
				value+=6;
				tField.setText(value);
			}
			if(a.getSource()==num7){
				value+=7;
				tField.setText(value);
			}
			if(a.getSource()==num8){
				value+=8;
				tField.setText(value);
			}
			if(a.getSource()==num9){
				value+=9;
				tField.setText(value);
			}
			if(a.getSource() == A)
			{
				value+="A";
				tField.setText(value);
			}
			if(a.getSource() == B)
			{
				value+="B";
				tField.setText(value);
			}
			if(a.getSource() == C)
			{
				value+="C";
				tField.setText(value);
			}
			if(a.getSource() == D)
			{
				value+="D";
				tField.setText(value);
			}
			if(a.getSource() == E)
			{
				value+="E";
				tField.setText(value);
			}
			if(a.getSource() == F)
			{
				value+="F";
				tField.setText(value);
			}
			if (a.getSource() == bAdd){
				if(Dec.isSelected() == true)
				{
					v1 = Double.valueOf(( tField.getText()) );
					ctr=0;
					o = '+';
					value="";
					tField.setText(String.valueOf(v1));
				}
				if(Bin.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 2);
					ctr=0;
					o = '+';
					value="";
					tField.setText(Integer.toBinaryString(bv1));
				}
				if(Hex.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 16);
					ctr=0;
					o = '+';
					value="";
					tField.setText(Integer.toHexString(bv1).toUpperCase());
				}
				if(Oct.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 8);
					ctr=0;
					o = '+';
					value="";
					tField.setText(Integer.toOctalString(bv1));
				}
			}

			if (a.getSource() == bSub){
				if(Dec.isSelected() == true)
				{
					v1 = Double.valueOf(( tField.getText()) );
					ctr=0;
					o = '-';
					value="";
					tField.setText(String.valueOf(s1));
					
				}
				if(Bin.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 2);
					ctr=0;
					o = '-';
					value="";
					tField.setText(Integer.toBinaryString(bv1));
				}
				if(Hex.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 16);
					ctr=0;
					o = '-';
					value="";
					tField.setText(Integer.toHexString(bv1).toUpperCase());
				}
				if(Oct.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 8);
					ctr=0;
					o = '-';
					value="";
					tField.setText(Integer.toOctalString(bv1));
				}
			}
			
			if (a.getSource() == bMul){
				if(Dec.isSelected() == true)
				{
					v1 = Double.valueOf(( tField.getText()) );
					ctr=0;
					o = 'x';
					value="";
					tField.setText(String.valueOf(v1));
				}
				if(Bin.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 2);
					ctr=0;
					o = 'x';
					value="";
					tField.setText(Integer.toBinaryString(bv1));
				}
				if(Hex.isSelected() == true)
				{
					bv1 = Integer.valueOf(tField.getText(), 16);
					ctr=0;
					o = 'x';
					value="";
					tField.setText(Integer.toHexString(bv1).toUpperCase());
				}
				if(Oct.isSelected() == true)
				{
					bv1 = Integer.valueOf(tField.getText(), 8);
					ctr=0;
					o = 'x';
					value="";
					tField.setText(Integer.toOctalString(bv1));
				}
			}

			if (a.getSource() == bDiv){
				if(Dec.isSelected() == true)
				{
					v1 = Double.valueOf(( tField.getText()) );
					ctr=0;
					o = '/';
					value="";
					tField.setText(String.valueOf(v1));
				}
				if(Bin.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 2);
					ctr=0;
					o = '/';
					value="";
					tField.setText(Integer.toBinaryString(bv1));
				}
				if(Hex.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 16);
					ctr=0;
					o = '/';
					value="";
					tField.setText(Integer.toHexString(bv1).toUpperCase());
				}
				if(Oct.isSelected() == true)
				{
					bv1 = Integer.parseInt(tField.getText(), 8);
					ctr=0;
					o = '/';
					value="";
					tField.setText(Integer.toOctalString(bv1));
				}
			}

		//EQUALS ACTION
			if(a.getSource()==equals){
						value="";
						if(Bin.isSelected() == true)
						{
							bv2 = Integer.parseInt(tField.getText(), 2);
						}
						if(Dec.isSelected() == true)
						{
							v2 = Double.parseDouble(tField.getText());
						}
						if(Hex.isSelected() == true)
						{
							bv2 = Integer.parseInt(tField.getText(), 16);
						}
						if(Oct.isSelected() == true)
						{
							bv2 = Integer.parseInt(tField.getText(), 8);
						}
						
					if(o=='+'){
						if(Dec.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							answer = v1+v2;
							tField.setText(String.valueOf(answer));
							value=""; v2=0;
						}
						if(Bin.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 + bv2;
							tField.setText(Integer.toBinaryString(banswer));
							value=""; bv2=0;bv1=0;
						}
						if(Hex.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 + bv2;
							tField.setText(Integer.toHexString(banswer).toUpperCase());
							value=""; bv2=0;bv1=0;
						}
						if(Oct.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 + bv2;
							tField.setText(Integer.toOctalString(banswer));
							value=""; bv2=0;bv1=0;
						}
					}
					else if(o=='-'){
						if(Dec.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							answer = v1-v2;
							tField.setText("" +(answer));
							value="";v2=0;
						}
						if(Bin.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 - bv2;
							tField.setText(Integer.toBinaryString(banswer));
							value=""; bv2=0;bv1=0;
						}
						if(Hex.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 - bv2;
							tField.setText(Integer.toHexString(banswer).toUpperCase());
							value=""; bv2=0;bv1=0;
						}
						if(Oct.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 - bv2;
							tField.setText(Integer.toOctalString(banswer));
							value=""; bv2=0;bv1=0;
						}
					}
					if(o=='x'){
						if(Dec.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							answer=v1*v2;
							tField.setText("" +answer);
							v1=0;v2=0;
						}
						if(Bin.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 * bv2;
							tField.setText(Integer.toBinaryString(banswer));
							bv2=0;bv1=0;
						}
						if(Hex.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 * bv2;
							tField.setText(Integer.toHexString(banswer).toUpperCase());
							bv2=0;bv1=0;
						}
						if(Oct.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 * bv2;
							tField.setText(Integer.toOctalString(banswer));
							bv2=0;bv1=0;
						}
						
					}
					else if(o=='/'){
						if(Dec.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							answer = v1/v2;
							tField.setText("" +answer);
							value="";v2=0;v1=0;
						}
						if(Bin.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 / bv2;
							tField.setText(Integer.toBinaryString(banswer));
							bv2=0;bv1=0;value="";
						}
						if(Hex.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 / bv2;
							tField.setText(Integer.toHexString(banswer).toUpperCase());
							bv2=0;bv1=0;value="";
						}
						if(Oct.isSelected() == true)
						{
							tField.setText("");
							ctr=0;
							banswer = bv1 / bv2;
							tField.setText(Integer.toOctalString(banswer));
							bv2=0;bv1=0;value="";
						}
						
					}
			}
			//r1=0;v1=0;m1=1;
		/* |-- EQUALS ACTION --| */
			/*	|-- Clear --| */

			if(a.getSource()==clear){
				ctr=0;
				v1=0;bv1=0;bv2=0;banswer=0;
				v2=0;
				value="";
				answer=0.;
				tField.setText("0");

			}
			if(a.getSource()==bCE)
			{
				ctr=0;
				value="";
				tField.setText("0.");
			}



			
			

			//Back Space
			if(a.getSource() == backspace){
					value = value.substring(0, value.length()-1 );
					tField.setText("" +value);
			}
			


			/* |-- Integer --| */
			if(a.getSource() == bInt){
				if(Dec.isSelected() == true)
				{
					ctr=0;
					NumberConverted = ( Integer.parseInt(tField.getText(),10) * -1 );
					value = "";
					tField.setText("" +NumberConverted);
				}
				if(Bin.isSelected() == true)
				{
					ctr=0;
					bNumberConverted = (Integer.parseInt(tField.getText(),2)*-1);
					value = "";
					tField.setText(Integer.toBinaryString(bNumberConverted));
				}
				if(Hex.isSelected() == true)
				{
					
					ctr=0;
					bNumberConverted = (Integer.parseInt(tField.getText(),16)*-1);
					value = "";
					tField.setText(Integer.toHexString(bNumberConverted).toUpperCase());
				}
				if(Oct.isSelected() == true)
				{
					ctr=0;
					bNumberConverted = (Integer.parseInt(tField.getText(),8)*-1);
					value = "";
					tField.setText(Integer.toOctalString(bNumberConverted));
				}
			}
			
			if(a.getSource() == Bin)
			{
				ctr=0;
				v1=0;bv1=0;bv2=0;banswer=0;
				v2=0;
				value="";
				answer=0.;
				tField.setText("0");
				num0.setEnabled(true); num1.setEnabled(true); num2.setEnabled(false); num3.setEnabled(false); num4.setEnabled(false); num5.setEnabled(false); num6.setEnabled(false); num7.setEnabled(false); num8.setEnabled(false);num9.setEnabled(false); 
				bAdd.setEnabled(true); bSub.setEnabled(true); bMul.setEnabled(true); bDiv.setEnabled(true); bInt.setEnabled(true); bCE.setEnabled(true); equals.setEnabled(true); backspace.setEnabled(true); clear.setEnabled(true);
				Dec.setSelected(false);Hex.setSelected(false);Oct.setSelected(false);
				A.setEnabled(false); B.setEnabled(false); C.setEnabled(false); D.setEnabled(false); E.setEnabled(false); F.setEnabled(false);
				//tField.setText("0");
				
			}
			
			if(a.getSource() == Dec)
			{
				ctr=0;
				v1=0;bv1=0;bv2=0;banswer=0;
				v2=0;
				value="";
				answer=0.;
				tField.setText("0");
				num0.setEnabled(true); num1.setEnabled(true); num2.setEnabled(true); num3.setEnabled(true); num4.setEnabled(true); num5.setEnabled(true); num6.setEnabled(true); num7.setEnabled(true); num8.setEnabled(true);num9.setEnabled(true); 
				bAdd.setEnabled(true); bSub.setEnabled(true); bMul.setEnabled(true); bDiv.setEnabled(true); bInt.setEnabled(true); bCE.setEnabled(true); equals.setEnabled(true); backspace.setEnabled(true); clear.setEnabled(true);
				Bin.setSelected(false);Hex.setSelected(false);Oct.setSelected(false);
				A.setEnabled(false); B.setEnabled(false); C.setEnabled(false); D.setEnabled(false); E.setEnabled(false); F.setEnabled(false);
				//tField.setText("0");
				
			}
			if(a.getSource() == Hex)
			{
				ctr=0;
				v1=0;bv1=0;bv2=0;banswer=0;
				v2=0;
				value="";
				answer=0.;
				tField.setText("0");
				num0.setEnabled(true); num1.setEnabled(true); num2.setEnabled(true); num3.setEnabled(true); num4.setEnabled(true); num5.setEnabled(true); num6.setEnabled(true); num7.setEnabled(true); num8.setEnabled(true);num9.setEnabled(true); 
				bAdd.setEnabled(true); bSub.setEnabled(true); bMul.setEnabled(true); bDiv.setEnabled(true); bInt.setEnabled(true); bCE.setEnabled(true); equals.setEnabled(true); backspace.setEnabled(true); clear.setEnabled(true);
				Dec.setSelected(false);Bin.setSelected(false);Oct.setSelected(false);
				A.setEnabled(true); B.setEnabled(true); C.setEnabled(true); D.setEnabled(true); E.setEnabled(true); F.setEnabled(true);
				//tField.setText("0");
			}
			if(a.getSource() == Oct)
			{
				ctr=0;
				v1=0;bv1=0;bv2=0;banswer=0;
				v2=0;
				value="";
				answer=0.;
				tField.setText("0");
				//temp = Integer.valueOf(tField.getText());
				num0.setEnabled(true); num1.setEnabled(true); num2.setEnabled(true); num3.setEnabled(true); num4.setEnabled(true); num5.setEnabled(true); num6.setEnabled(true); num7.setEnabled(true); num8.setEnabled(false);num9.setEnabled(false); 
				bAdd.setEnabled(true); bSub.setEnabled(true); bMul.setEnabled(true); bDiv.setEnabled(true); bInt.setEnabled(true); bCE.setEnabled(true); equals.setEnabled(true); backspace.setEnabled(true); clear.setEnabled(true);
				Dec.setSelected(false);Bin.setSelected(false);Hex.setSelected(false);
				A.setEnabled(false); B.setEnabled(false); C.setEnabled(false); D.setEnabled(false); E.setEnabled(false); F.setEnabled(false);
			}





			

		}
		catch (final Exception e) {
			// TODO: handle exception
			//e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Syntax Error");
		}
	}

   
}
