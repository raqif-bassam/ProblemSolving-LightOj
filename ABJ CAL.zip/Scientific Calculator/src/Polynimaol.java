/*import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class Polynimaol extends JPanel{
	//double []q;
	JFrame f;
	JButton graph;
	JLabel lblA,lblB,lblC;
	JTextField txtA,txtB,txtC;
	String co3;
	String co2;
	String co;
	Integer co3val,co2val,coval;
	public Polynimaol(){
		f = new JFrame("Quadatric Graphs");
		f.setSize(550,200);
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		f.setVisible(true);
		addComponent();
		txtA.setText("0");
		txtB.setText("0");
		txtC.setText("0");
	}
	public void addComponent(){
		lblA=new JLabel("a=");
		lblB=new JLabel("b=");
		lblC=new JLabel("c=");
		txtA=new JTextField();
		txtA.setText("0");
		txtB=new JTextField();
		txtC=new JTextField();
		graph=new JButton("Graph It");
		
		
		lblA.setBounds(10,10, 20,20);
		txtA.setBounds(30, 10,70,20);
		lblB.setBounds(110,10,20 ,20);
		txtB.setBounds(130,10,70,20);
		lblC.setBounds(210,10,20,20);
		txtC.setBounds(230,10,70,20);
		graph.setBounds(320,10,90,20);
		
		f.add(lblA);
		f.add(txtA);
		f.add(lblB);
		f.add(txtB);
		f.add(lblC);
		f.add(txtC);
		f.add(graph);
		
		
		
		graph.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e)
			{
				co3=txtA.getText();
				co2=txtB.getText();
				co=txtC.getText();
				co3val=Integer.parseInt(co3);
				co2val=Integer.valueOf(co2);
				coval=Integer.valueOf(co);
				//System.out.println(""+co3val);
				
				//new PolyGraph(co3val,co2val,coval);
			}
			
		});
		//f.setVisible(true);
		
	}

}
*/